from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import logout
from yp.models import Product
from yp.models import User as YPUser


def login_page(request):
    return render(request, 'login.html')


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')

        try:
            yp_user = YPUser.objects.get(login=username, password=password)
            request.session['yp_user_id'] = yp_user.id
            request.session['yp_user_name'] = yp_user.full_name
            request.session['yp_user_role'] = yp_user.role.name
            return redirect('products')
        except YPUser.DoesNotExist:
            messages.error(request, 'Неверный логин или пароль.')
            return redirect('login_page')
    return redirect('login_page')


def register_view(request):
    if request.method == 'POST':
        username  = request.POST.get('username', '').strip()
        full_name = request.POST.get('full_name', '').strip()
        password1 = request.POST.get('password1', '')
        password2 = request.POST.get('password2', '')

        if not username or not full_name or not password1:
            messages.error(request, 'Все поля обязательны.')
            return redirect('/login/?tab=register')
        if password1 != password2:
            messages.error(request, 'Пароли не совпадают.')
            return redirect('/login/?tab=register')
        if len(password1) < 6:
            messages.error(request, 'Пароль должен быть не менее 6 символов.')
            return redirect('/login/?tab=register')
        if YPUser.objects.filter(login=username).exists():
            messages.error(request, f'Пользователь «{username}» уже существует.')
            return redirect('/login/?tab=register')

        from yp.models import EmployeeRole
        role = EmployeeRole.objects.get(id=3)

        # Берём максимальный id и прибавляем 1
        last_id = YPUser.objects.order_by('-id').first()
        new_id = (last_id.id + 1) if last_id else 1

        user = YPUser.objects.create(
            id=new_id,
            login=username,
            full_name=full_name,
            password=password1,
            role=role,
        )
        request.session['yp_user_id'] = user.id
        request.session['yp_user_name'] = user.full_name
        request.session['yp_user_role'] = role.name
        return redirect('products')
    return redirect('login_page')


def guest_view(request):
    request.session['yp_user_id'] = None
    request.session['yp_user_name'] = 'Гость'
    request.session['yp_user_role'] = 'guest'
    return redirect('products')


def logout_view(request):
    request.session.flush()
    return redirect('login_page')


def products_view(request):
    if not request.session.get('yp_user_name'):
        return redirect('login_page')

    products = Product.objects.select_related(
        'category', 'manufacturer', 'supplier'
    ).all()

    for p in products:
        p.final_price = round(float(p.price) * (1 - float(p.discount) / 100), 2)

    context = {
        'products': products,
        'username': request.session.get('yp_user_name', 'Гость'),
        'role': request.session.get('yp_user_role', 'guest'),
    }
    return render(request, 'products.html', context)