from django.db import models


class EmployeeRole(models.Model):
    name = models.CharField(max_length=100)

    class Meta:
        db_table = 'employee_role'

    def __str__(self):
        return self.name


class User(models.Model):
    role = models.ForeignKey(EmployeeRole, on_delete=models.SET_NULL, null=True)
    full_name = models.CharField(max_length=200)
    login = models.CharField(max_length=100, unique=True)
    password = models.CharField(max_length=255)

    class Meta:
        db_table = 'user'

    def __str__(self):
        return self.full_name


class Supplier(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        db_table = 'supplier'

    def __str__(self):
        return self.name


class Manufacturer(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        db_table = 'manufacturer'

    def __str__(self):
        return self.name


class ProductCategory(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        db_table = 'product_category'

    def __str__(self):
        return self.name


class Product(models.Model):
    article = models.CharField(max_length=100, primary_key=True)
    name = models.CharField(max_length=200)
    unit = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    supplier = models.ForeignKey(Supplier, on_delete=models.SET_NULL, null=True)
    manufacturer = models.ForeignKey(Manufacturer, on_delete=models.SET_NULL, null=True)
    category = models.ForeignKey(ProductCategory, on_delete=models.SET_NULL, null=True)
    discount = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    stock = models.IntegerField(default=0)
    description = models.TextField(blank=True)
    photo = models.CharField(max_length=500, blank=True)

    class Meta:
        db_table = 'product'

    def __str__(self):
        return self.name


class PickupPoint(models.Model):
    index = models.CharField(max_length=20)
    street = models.CharField(max_length=200)
    city = models.CharField(max_length=100)
    house = models.CharField(max_length=20)

    class Meta:
        db_table = 'pickup_point'

    def __str__(self):
        return f'{self.city}, {self.street}, {self.house}'


class OrderStatus(models.Model):
    state = models.CharField(max_length=100)

    class Meta:
        db_table = 'order_status'

    def __str__(self):
        return self.state


class Order(models.Model):
    order_number = models.CharField(max_length=100)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    quantity = models.IntegerField()
    order_date = models.DateField()
    delivery_date = models.DateField(null=True, blank=True)
    pickup_point = models.ForeignKey(PickupPoint, on_delete=models.SET_NULL, null=True)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    pickup_code = models.CharField(max_length=100, blank=True)
    status = models.ForeignKey(OrderStatus, on_delete=models.SET_NULL, null=True)

    class Meta:
        db_table = 'order'

    def __str__(self):
        return self.order_number


