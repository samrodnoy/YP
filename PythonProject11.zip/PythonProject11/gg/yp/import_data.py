import os
import sys
import django
import csv
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'gg.settings')
django.setup()

from yp.models import (
    EmployeeRole, User, Supplier, Manufacturer,
    ProductCategory, Product, PickupPoint, OrderStatus, Order
)

BASE = 'Импорт2/'


def import_roles():
    with open(BASE + 'role.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            EmployeeRole.objects.get_or_create(
                id=row['id'],
                defaults={'name': row['Роль сотрудника']}
            )
    print('Роли импортированы')


def import_suppliers():
    with open(BASE + 'postavchik.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            Supplier.objects.get_or_create(
                id=row['id'],
                defaults={'name': row['Поставщик']}
            )
    print('Поставщики импортированы')


def import_manufacturers():
    with open(BASE + 'proizvoditel.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            Manufacturer.objects.get_or_create(
                id=row['id'],
                defaults={'name': row['Производитель']}
            )
    print('Производители импортированы')


def import_categories():
    with open(BASE + 'category_tovar.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            ProductCategory.objects.get_or_create(
                id=row['id'],
                defaults={'name': row['Категория']}
            )
    print('Категории импортированы')


def import_statuses():
    with open(BASE + 'status.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            OrderStatus.objects.get_or_create(
                id=row['id'],
                defaults={'state': row['Состояние']}
            )
    print('Статусы импортированы')


def import_pickup_points():
    with open(BASE + 'Пункты выдачи_import.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            PickupPoint.objects.get_or_create(
                id=row['id'],
                defaults={
                    'index':  row['индекс'].strip(),
                    'city':   row['город'].strip(),
                    'street': row['улица'].strip(),
                    'house':  row['дом'].strip(),
                }
            )
    print('Пункты выдачи импортированы')


def import_users():
    with open(BASE + 'user_import.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            role = EmployeeRole.objects.get(id=row['Роль сотрудника'])
            User.objects.get_or_create(
                id=row['id'],
                defaults={
                    'role':      role,
                    'full_name': row['ФИО'],
                    'login':     row['Логин'],
                    'password':  row['Пароль'],
                }
            )
    print('Пользователи импортированы')


def import_products():
    with open(BASE + 'Tovar.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            Product.objects.get_or_create(
                article=row['Артикул'].strip(),
                defaults={
                    'name':         row['Наименование товара'],
                    'unit':         row['Единица измерения'],
                    'price':        row['Цена'],
                    'supplier':     Supplier.objects.get(id=row['Поставщик']),
                    'manufacturer': Manufacturer.objects.get(id=row['Производитель']),
                    'category':     ProductCategory.objects.get(id=row['Категория товара']),
                    'discount':     row['Действующая скидка'],
                    'stock':        row['Кол-во на складе'],
                    'description':  row['Описание товара'],
                    'photo':        row['Фото'],
                }
            )
    print('Товары импортированы')


def parse_date(date_str):
    date_str = date_str.strip()
    try:
        if '.' in date_str:
            parts = date_str.split('.')
            if len(parts[2]) == 2:
                parts[2] = '20' + parts[2]
            return f'{parts[2]}-{parts[1]}-{parts[0]}'
        return date_str
    except Exception:
        return None


def import_orders():
    with open(BASE + 'Заказ_import.csv', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            article = row['Артикул товара'].strip().rstrip(',')
            try:
                product = Product.objects.get(article=article)
            except Product.DoesNotExist:
                print(f'Товар {article} не найден, пропускаем')
                continue

            order_date    = parse_date(row['Дата заказа'])
            delivery_date = parse_date(row['Дата доставки'])

            try:
                if order_date:
                    datetime.strptime(order_date, '%Y-%m-%d')
                if delivery_date:
                    datetime.strptime(delivery_date, '%Y-%m-%d')
            except ValueError:
                print(f'Невалидная дата в заказе ID={row["ID"]}, пропускаем')
                continue

            Order.objects.get_or_create(
                id=row['ID'],
                defaults={
                    'order_number':  row['Номер заказа'],
                    'product':       product,
                    'quantity':      row['Количество'],
                    'order_date':    order_date,
                    'delivery_date': delivery_date,
                    'pickup_point':  PickupPoint.objects.get(id=row['Адрес пункта выдачи']),
                    'user':          User.objects.get(id=row['ФИО авторизированного клиента']),
                    'pickup_code':   row['Код для получения'],
                    'status':        OrderStatus.objects.get(id=row['Статус заказа']),
                }
            )
    print('Заказы импортированы')


if __name__ == '__main__':
    import_roles()
    import_suppliers()
    import_manufacturers()
    import_categories()
    import_statuses()
    import_pickup_points()
    import_users()
    import_products()
    import_orders()
    print('Импорт завершён!')